import os
os.system('cmd /k "python -m venv venv')
os.system('cmd /k ".\venv\Scripts\activate')
os.system('cmd /k "pip install -r requirements.txt')
